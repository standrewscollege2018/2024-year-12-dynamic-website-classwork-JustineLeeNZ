
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>El Sombrero Restaurant</title>
  </head>
  <body>

    <h1>Menu</h1>

    <?php
    // connect to database
      $dbconnect = mysqli_connect("localhost", "root", "root", "elsombrero_demo");
    ?>

    <?php

      // run query to get all items in menu
      $item_sql = "SELECT * FROM menu";
      $item_query = mysqli_query($dbconnect, $item_sql);
      $item_rs = mysqli_fetch_assoc($item_query);

    ?>

    <!-- loop through all menu items for specified course -->

    <?php

      do {
        // heading, description, price for current menu item
        
          echo "<h3>", $item_rs['name'], "</h3>"; 
          echo "<p>";
          echo $item_rs['description'];
          echo "&nbsp<b>";
          echo $item_rs['price'];
          echo "</b></p>";

        
      } while ($item_rs = mysqli_fetch_assoc($item_query));

    ?>



  </body>
</html>
